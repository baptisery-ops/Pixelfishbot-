package com.example.pixelfish

import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min

/**
 * Zero-allocation per-frame analysis straight off the RGBA buffer.
 *  ring  = centroid of the green top+bottom strokes of the ring (symmetric, so the fish can never bias it)
 *  fish  = dark-navy/red pixels (outside OR inside the ring) + solid-green pixels inside the ring
 * Positions are in capture pixels (float, sub-pixel).
 */
class Detector {
    var present = false; private set
    var ringX = Float.NaN; private set
    var fishX = Float.NaN; private set
    var strike = false; private set
    var width = 1; private set

    private var rowG = BooleanArray(2048)

    fun analyze(buf: ByteBuffer, stride: Int, w: Int, h: Int) {
        width = w
        val s = w / Config.REF_W
        val s2 = s * s
        analyzeBar(buf, stride, w, h, s2)
        analyzeHook(buf, stride, w, h)
    }

    private fun analyzeBar(buf: ByteBuffer, stride: Int, w: Int, h: Int, s2: Float) {
        ringX = Float.NaN; fishX = Float.NaN
        // ---- presence: tight blue box (sky/purple backgrounds do NOT match) ----
        val bx0 = (Config.BAR_X0 * w).toInt(); val bx1 = (Config.BAR_X1 * w).toInt()
        val by0 = (Config.BAR_Y0 * h).toInt(); val by1 = (Config.BAR_Y1 * h).toInt()
        var hit = 0; var tot = 0
        var y = by0
        while (y < by1) {
            var x = bx0
            while (x < bx1) {
                val o = y * stride + x * 4
                val r = buf.get(o).toInt() and 0xFF
                val g = buf.get(o + 1).toInt() and 0xFF
                val b = buf.get(o + 2).toInt() and 0xFF
                tot++
                if (r < 75 && g > 80 && g < 150 && b > 140 && b < 225 && b - g > 40) hit++
                x += 2
            }
            y += 2
        }
        present = tot > 0 && hit.toFloat() / tot > Config.BAR_BG_FRAC
        if (!present) return

        // ---- ring centre from the top and bottom strokes ----
        val sx0 = (Config.SCAN_X0 * w).toInt(); val sx1 = (Config.SCAN_X1 * w).toInt()
        var sumW = 0f; var sumWX = 0f
        for (band in 0..1) {
            val ya = ((if (band == 0) Config.RING_TOP_Y0 else Config.RING_BOT_Y0) * h).toInt()
            val yb = ((if (band == 0) Config.RING_TOP_Y1 else Config.RING_BOT_Y1) * h).toInt()
            for (yy in ya until yb) {
                var x = sx0
                while (x < sx1) {
                    val o = yy * stride + x * 4
                    val r = buf.get(o).toInt() and 0xFF
                    val g = buf.get(o + 1).toInt() and 0xFF
                    val b = buf.get(o + 2).toInt() and 0xFF
                    val sc = g - max(r, b)
                    if (sc > 60) {
                        val wt = min(1f, (sc - 60) / 130f)
                        sumW += wt; sumWX += wt * x
                    }
                    x++
                }
            }
        }
        if (sumW < Config.MIN_RING_MASS * s2) return
        val ring = sumWX / sumW
        ringX = ring

        // ---- fish ----
        val fx0 = (Config.FISH_X0 * w).toInt(); val fx1 = (Config.FISH_X1 * w).toInt()
        val n = fx1 - fx0
        if (rowG.size < n + 4) rowG = BooleanArray(n + 4)
        val fy0 = (Config.FISH_Y0 * h).toInt(); val fy1 = (Config.FISH_Y1 * h).toInt()
        val gy0 = (Config.FISHG_Y0 * h).toInt(); val gy1 = (Config.FISHG_Y1 * h).toInt()
        val half = Config.RING_HALF_W * w * 0.55f
        val gl = ring - half; val gr = ring + half
        var nD = 0; var sDX = 0f
        var nG = 0; var sGX = 0f
        for (yy in fy0 until fy1) {
            for (i in 0 until n) {
                val o = yy * stride + (fx0 + i) * 4
                val r = buf.get(o).toInt() and 0xFF
                val g = buf.get(o + 1).toInt() and 0xFF
                val b = buf.get(o + 2).toInt() and 0xFF
                rowG[i] = (g - max(r, b)) > 90
            }
            val inGreenBand = yy in gy0 until gy1
            for (i in 0 until n) {
                val x = fx0 + i
                if (rowG[i]) {
                    if (inGreenBand && x >= gl && x <= gr) { nG++; sGX += x }
                    continue
                }
                val nearGreen = (i > 0 && rowG[i - 1]) || (i + 1 < n && rowG[i + 1]) ||
                    (i > 1 && rowG[i - 2]) || (i + 2 < n && rowG[i + 2])
                if (nearGreen) continue
                val o = yy * stride + x * 4
                val r = buf.get(o).toInt() and 0xFF
                val g = buf.get(o + 1).toInt() and 0xFF
                val b = buf.get(o + 2).toInt() and 0xFF
                val navy = r < 60 && g < 90 && b > 50 && b < 150
                val red = r > 140 && g < 90 && b < 90
                if (navy || red) { nD++; sDX += x }
            }
        }
        val mass = nD + nG
        if (mass >= Config.MIN_FISH_MASS * s2) fishX = (sDX + sGX) / mass
    }

    private fun analyzeHook(buf: ByteBuffer, stride: Int, w: Int, h: Int) {
        val cx = (Config.ACTION_X * w).toInt(); val cy = (Config.BTN_Y * h).toInt()
        val half = (Config.HOOK_HALF * w).toInt()
        var green = 0; var total = 0
        var y = cy - half
        while (y < cy + half) {
            var x = cx - half
            while (x < cx + half) {
                val o = y * stride + x * 4
                val r = buf.get(o).toInt() and 0xFF
                val g = buf.get(o + 1).toInt() and 0xFF
                val b = buf.get(o + 2).toInt() and 0xFF
                total++
                if (g > 190 && r < 90 && b < 90) green++
                x += 2
            }
            y += 2
        }
        strike = total > 0 && green.toFloat() / total > Config.STRIKE_GREEN_FRAC
    }
}
