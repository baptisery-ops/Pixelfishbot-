package com.example.pixelfish

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Path
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.accessibility.AccessibilityEvent

/**
 * Low-latency input. A hold is ONE long stroke; to switch or release we simply dispatch a new gesture,
 * which makes Android cancel the one in flight immediately (no waiting for a chunk to finish, no chained
 * continueStroke round-trips). Release = a 1 ms touch on the same button.
 */
class BotAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: BotAccessibilityService? = null
        private const val HOLD_MS = 30_000L
        private const val REFRESH_MS = 25_000L
    }

    private var sw = 0
    private var sh = 0
    private var heldDir = 0
    private var heldSince = 0L

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { heldDir = 0 }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    @Suppress("DEPRECATION")
    private fun refreshSize() {
        val dm = DisplayMetrics()
        (getSystemService(WINDOW_SERVICE) as android.view.WindowManager).defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels; sh = dm.heightPixels
    }

    private fun send(xf: Float, yf: Float, durMs: Long) {
        val p = Path().apply { moveTo(xf * sw, yf * sh) }
        dispatchGesture(GestureDescription.Builder().addStroke(StrokeDescription(p, 0, durMs)).build(), null, null)
    }

    @Synchronized
    fun tap(xf: Float, yf: Float) {
        refreshSize(); send(xf, yf, 60); heldDir = 0
    }

    private fun btnX(dir: Int) = if (dir < 0) Config.LEFT_X else Config.RIGHT_X

    /** dir: -1 hold left, +1 hold right, 0 release. Safe to call every frame. */
    @Synchronized
    fun setHold(dir: Int) {
        val now = SystemClock.uptimeMillis()
        if (dir == heldDir) {
            if (dir != 0 && now - heldSince > REFRESH_MS) { refreshSize(); send(btnX(dir), Config.BTN_Y, HOLD_MS); heldSince = now }
            return
        }
        refreshSize()
        if (dir == 0) send(btnX(heldDir), Config.BTN_Y, 1)      // cancels the long hold right away
        else { send(btnX(dir), Config.BTN_Y, HOLD_MS); heldSince = now }
        heldDir = dir
    }
}
