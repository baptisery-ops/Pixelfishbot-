package com.example.pixelfish

import android.util.Log
import java.io.File
import kotlin.math.max

/**
 * Controller built from measurements of the real game:
 *  - the ring is a pure constant-speed integrator (+-RING_SPEED or stopped, no inertia)
 *  - so we use a Smith predictor: we know every command we issued, so we know where the ring WILL be
 *    once the commands still "in the pipe" (loop latency T) take effect, and we steer that predicted
 *    ring toward the predicted fish. No smoothing of the ring (smoothing = lag = jank).
 *  - T is measured live (time from pressing a button to the ring visibly starting to move).
 */
class Bot {
    private enum class S { IDLE, FISHING }

    private var state = S.IDLE
    private var lastBarSeen = 0.0
    private var lastTap = -1e9
    private var nextCastAt = 0.0
    private var strikeSince = -1.0

    // fish tracker (alpha-beta), units = fraction of capture width
    private var fx = 0f; private var fv = 0f; private var fT = 0.0
    private var fValid = false; private var fLastMeas = 0.0

    // command state + history (for the Smith predictor)
    private var u = 0
    private var lastChange = -1e9
    private val hT = DoubleArray(64); private val hU = IntArray(64)
    private var hHead = 0; private var hCount = 0

    // live latency calibration
    private var loopT = Config.LOOP_LATENCY_MS
    private var probeOn = false; private var probeT0 = 0.0; private var probeX0 = 0f; private var probeDir = 0
    private val samples = ArrayList<Double>()

    private val tele = Telemetry()

    private fun svc() = BotAccessibilityService.instance

    fun onFrame(d: Detector, now: Double) {
        val a = svc() ?: return
        if (d.present) {
            if (state != S.FISHING) {
                state = S.FISHING; fValid = false; strikeSince = -1.0
                Log.d(TAG, "fish on")
            }
            lastBarSeen = now
            val w = d.width.toFloat()
            val ring = if (d.ringX.isNaN()) Float.NaN else d.ringX / w
            val fish = if (d.fishX.isNaN()) Float.NaN else d.fishX / w
            control(ring, fish, now, a)
            return
        }
        // ---- bar not visible ----
        if (state == S.FISHING) {
            if (now - lastBarSeen < Config.BAR_LOST_MS) return
            state = S.IDLE
            command(0, now, Float.NaN, a)
            nextCastAt = now + Config.POST_FISH_DELAY_MS
            lastTap = now
            Log.d(TAG, "fish done (latency ${"%.0f".format(loopT)} ms)")
            return
        }
        if (d.strike) {
            if (strikeSince < 0) strikeSince = now
            if (now - strikeSince >= Config.STRIKE_DELAY_MS && now - lastTap > Config.STRIKE_COOLDOWN_MS) {
                a.tap(Config.ACTION_X, Config.BTN_Y); lastTap = now; strikeSince = -1.0
                Log.d(TAG, "strike")
            }
        } else {
            strikeSince = -1.0
            if (now >= nextCastAt && now - lastTap > Config.CAST_RETRY_MS) {
                a.tap(Config.ACTION_X, Config.BTN_Y); lastTap = now
                Log.d(TAG, "cast")
            }
        }
    }

    // ------------------------------------------------------------------ fishing

    private fun control(ring: Float, fishMeas: Float, now: Double, a: BotAccessibilityService) {
        updateFish(fishMeas, now)
        if (ring.isNaN() || !fValid) { command(0, now, ring, a); return }
        updateProbe(ring, now)

        val pend = pending(now, loopT)                       // seconds of net "ring-direction" commanded but not yet visible
        val xp = ring + Config.RING_SPEED * pend.toFloat()   // where the ring will be when a new command lands
        val fp = fx + fv * Config.FISH_VEL_GAIN * (loopT / 1000.0).toFloat()
        val e = fp - xp
        val want = if (e > Config.DEADBAND) 1 else if (e < -Config.DEADBAND) -1 else 0
        command(want, now, ring, a)
        tele.add(now, ring, fishMeas, fx, u, e, loopT)
    }

    private fun updateFish(m: Float, t: Double) {
        if (!fValid) {
            if (m.isNaN()) return
            fx = m; fv = 0f; fT = t; fValid = true; fLastMeas = t
            return
        }
        val dt = ((t - fT) / 1000.0).coerceIn(0.004, 0.1).toFloat()
        fT = t
        val pr = fx + fv * dt
        if (m.isNaN()) {                                      // fish hidden: coast on its last velocity
            fx = pr
            if (t - fLastMeas > 300) fValid = false
            return
        }
        val r = m - pr
        fx = pr + Config.FISH_ALPHA * r
        fv = (fv + Config.FISH_BETA * r / dt).coerceIn(-Config.MAX_FISH_SPEED, Config.MAX_FISH_SPEED)
        fLastMeas = t
    }

    /** Net commanded ring motion (in seconds * direction) issued during the last [T] ms. */
    private fun pending(now: Double, T: Double): Double {
        val lo = now - T
        var pend = 0.0
        var end = now
        var k = hHead
        var c = 0
        while (c < hCount) {
            val s = max(hT[k], lo)
            if (end > s) pend += hU[k] * (end - s)
            end = hT[k]
            if (end <= lo) break
            k = (k + 63) and 63
            c++
        }
        return pend / 1000.0
    }

    /** Change the held direction (ring direction: -1, 0, +1), rate limited. */
    private fun command(want: Int, now: Double, ring: Float, a: BotAccessibilityService) {
        if (want == u) return
        if (now - lastChange < Config.MIN_DWELL_MS) return
        // start a latency probe when pressing from a standstill with nothing pending
        probeOn = want != 0 && u == 0 && now - lastChange > 300 && !ring.isNaN()
        if (probeOn) { probeT0 = now; probeX0 = ring; probeDir = want }
        u = want; lastChange = now
        hHead = (hHead + 1) and 63
        hT[hHead] = now; hU[hHead] = u
        if (hCount < 64) hCount++
        a.setHold(if (Config.INVERT_CONTROLS) -u else u)
    }

    private fun updateProbe(ring: Float, now: Double) {
        if (!probeOn) return
        if (u != probeDir) { probeOn = false; return }
        val moved = (ring - probeX0) * probeDir
        if (moved > Config.PROBE_MOVE) {
            val sample = (now - probeT0) - Config.PROBE_MOVE / Config.RING_SPEED * 1000.0
            samples.add(sample); if (samples.size > 9) samples.removeAt(0)
            val sorted = samples.sorted()
            loopT = sorted[sorted.size / 2].coerceIn(Config.LATENCY_MIN_MS, Config.LATENCY_MAX_MS)
            probeOn = false
        } else if (now - probeT0 > 400) probeOn = false
    }

    fun release() {
        svc()?.setHold(0)
        u = 0; state = S.IDLE; probeOn = false
    }

    fun dumpLog(f: File) = tele.dump(f)

    companion object { const val TAG = "PixelFish" }
}

/** Fixed-size in-memory log, written as CSV when the bot stops. Send me this file to tune further. */
class Telemetry {
    private val cap = 40000
    private val d = FloatArray(cap * 7)
    private var n = 0
    fun add(t: Double, ring: Float, fishMeas: Float, fishFilt: Float, u: Int, e: Float, lat: Double) {
        if (n >= cap) return
        val o = n * 7
        d[o] = (t / 1000.0).toFloat(); d[o + 1] = ring; d[o + 2] = fishMeas; d[o + 3] = fishFilt
        d[o + 4] = u.toFloat(); d[o + 5] = e; d[o + 6] = lat.toFloat()
        n++
    }
    fun dump(f: File) {
        if (n == 0) return
        f.bufferedWriter().use { w ->
            w.write("t_s,ring,fish_meas,fish_filt,cmd,pred_err,latency_ms\n")
            for (i in 0 until n) {
                val o = i * 7
                w.write("${d[o]},${d[o + 1]},${d[o + 2]},${d[o + 3]},${d[o + 4].toInt()},${d[o + 5]},${d[o + 6]}\n")
            }
        }
    }
}
