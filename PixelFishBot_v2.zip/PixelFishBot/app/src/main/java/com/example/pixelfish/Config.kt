package com.example.pixelfish

/**
 * Everything here was measured from your screen recording (1560x720 landscape).
 * Positions are FRACTIONS of screen width/height; speeds are in screen-widths per second,
 * so it scales to the capture resolution automatically.
 *
 * Measured facts about the game (from 60 fps analysis of the recording):
 *  - the ring moves at a constant +-0.1538 screen-widths/s while a button is held, and stops instantly
 *  - the progress bar only rises while |fish - ring centre| < ~0.0083 screen-widths (the ring looks wider than the scoring zone)
 *  - the fish turns solid green when it is inside the ring
 */
object Config {
    const val CAPTURE_SCALE = 0.5f
    const val REF_W = 780f                   // capture width the pixel counts below were measured at

    // ---- geometry (fractions of screen) ----
    const val BAR_X0 = 0.2956f; const val BAR_X1 = 0.7033f      // blue bar interior (presence test)
    const val BAR_Y0 = 0.1272f; const val BAR_Y1 = 0.1807f
    const val SCAN_X0 = 0.27f;  const val SCAN_X1 = 0.73f       // where the ring can be
    const val RING_TOP_Y0 = 0.1125f; const val RING_TOP_Y1 = 0.1250f   // ring's top stroke (fish never reaches here)
    const val RING_BOT_Y0 = 0.1797f; const val RING_BOT_Y1 = 0.1920f   // ring's bottom stroke
    const val FISH_X0 = 0.2878f; const val FISH_X1 = 0.7136f
    const val FISH_Y0 = 0.133f;  const val FISH_Y1 = 0.177f     // middle band where the fish is visible
    const val FISHG_Y0 = 0.1383f; const val FISHG_Y1 = 0.1689f  // band used for "solid green fish inside ring"
    const val RING_HALF_W = 0.025f

    // hook / net button (also the strike indicator)
    const val ACTION_X = 0.94f
    const val BTN_Y = 0.868f
    const val LEFT_X = 0.061f
    const val RIGHT_X = 0.157f
    const val HOOK_HALF = 0.028f
    const val STRIKE_GREEN_FRAC = 0.03f      // idle = 0.000, strike = 0.064 on your recording

    // ---- detection thresholds ----
    const val BAR_BG_FRAC = 0.40f
    const val MIN_RING_MASS = 15f
    const val MIN_FISH_MASS = 15f

    // ---- controller ----
    const val RING_SPEED = 0.1538f           // screen-widths / s
    const val DEADBAND = 0.0032f             // ~2.5 px at 780 wide; scoring zone is +-0.0083
    const val FISH_VEL_GAIN = 0.5f           // how much fish velocity to lead by (0 = none, 1 = full)
    const val FISH_ALPHA = 0.8f              // fish tracker gains (alpha-beta); high = low lag
    const val FISH_BETA = 0.4f
    const val MAX_FISH_SPEED = 0.45f
    const val MIN_DWELL_MS = 33.0            // min time between command changes (limits gesture spam)
    const val LOOP_LATENCY_MS = 100.0        // initial guess; auto-calibrated while running
    const val LATENCY_MIN_MS = 40.0
    const val LATENCY_MAX_MS = 220.0
    const val PROBE_MOVE = 0.0019f           // ring displacement that counts as "started moving"
    const val INVERT_CONTROLS = false

    // ---- timing (ms) ----
    const val STRIKE_DELAY_MS = 950.0        // wait this long after the hook turns green before tapping
    const val STRIKE_COOLDOWN_MS = 1500.0
    const val BAR_LOST_MS = 700.0
    const val POST_FISH_DELAY_MS = 1800.0
    const val CAST_RETRY_MS = 15000.0
}
