# Pixel Fish Bot v2 (rewrite of detector + controller)

Open in Android Studio, sync, run. Flow unchanged: enable accessibility service -> Start -> go to the fishing spot (landscape).

What changed (all measured from your recording, see Config.kt header):
- Detector: ring centre from the ring's top/bottom strokes (fish can't bias it), fish = navy/red pixels + solid-green pixels
  inside the ring, tight blue-bar test (the old test also matched the night sky), strict green strike test.
- Controller: no smoothing. Smith predictor (knows its own pending commands) + alpha-beta fish tracker with velocity lead.
  Loop latency is measured live.
- Input: one long stroke per hold, new gesture cancels it instantly (old chunk chain delayed releases by up to 120 ms).
- Strike tap waits Config.STRIKE_DELAY_MS (950 ms) after the hook turns green.
- fishlog.csv is written on Stop (Android/data/com.example.pixelfish/files/) - send it back to tune further.

Tuning: Config.kt. If the ring moves the wrong way set INVERT_CONTROLS. adb logcat -s PixelFish shows the measured latency.
