package com.example.pixelfish

/**
 * All geometry is in FRACTIONS of the screen (landscape), measured from your recording,
 * so it is resolution independent. Tune these first if detection misbehaves.
 */
object Config {
    const val CAPTURE_SCALE = 0.5f          // capture at half resolution (cheap, plenty for color blobs)

    // Blue fishing bar (inner area, inset from the white border)
    const val BAR_LEFT = 0.30f
    const val BAR_RIGHT = 0.70f
    const val BAR_TOP = 0.125f
    const val BAR_BOTTOM = 0.175f

    // Buttons (centers)
    const val LEFT_X = 0.061f
    const val RIGHT_X = 0.157f
    const val ACTION_X = 0.94f              // hook / net button
    const val BTN_Y = 0.868f

    // Hook button region used to detect the green "STRIKE!" state
    const val HOOK_HALF = 0.028f
    const val HOOK_GREEN_FRAC = 0.08f

    // Detection thresholds
    const val BAR_BLUE_FRAC = 0.30f         // fraction of bar ROI that must be blue => "fish on"
    const val MIN_RING_PIXELS = 8
    const val MIN_FISH_PIXELS = 6
    const val RING_EXCLUDE_FRAC = 0.07f     // ignore dark pixels near ring (its outline) – fraction of bar width

    // Controller (errors are fractions of bar width)
    const val ENTER_DEADZONE = 0.035f       // start moving when |fish - ring| exceeds this
    const val EXIT_DEADZONE = 0.015f        // stop moving when inside this
    const val INVERT_CONTROLS = false       // flip if the ring moves the wrong way

    // Timing (ms)
    const val BAR_LOST_MS = 700L            // bar gone this long => fish finished
    const val POST_FISH_DELAY_MS = 1800L    // wait before recasting
    const val STRIKE_COOLDOWN_MS = 500L
    const val CAST_RETRY_MS = 15000L        // recast if nothing happens for this long
    const val HOLD_CHUNK_MS = 120L          // length of each chained hold segment
}
