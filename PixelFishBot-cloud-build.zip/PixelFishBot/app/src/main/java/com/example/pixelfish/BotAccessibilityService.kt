package com.example.pixelfish

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Path
import android.util.DisplayMetrics
import android.view.accessibility.AccessibilityEvent

/** Injects taps and chained "holds" for the on-screen buttons. */
class BotAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: BotAccessibilityService? = null
    }

    private var sw = 0
    private var sh = 0
    @Volatile private var desiredDir = 0          // -1 left, 0 none, 1 right
    private var activeDir = 0
    private var stroke: StrokeDescription? = null
    private var path: Path? = null

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { desiredDir = 0 }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    @Suppress("DEPRECATION")
    private fun refreshSize() {
        val dm = DisplayMetrics()
        (getSystemService(android.content.Context.WINDOW_SERVICE) as android.view.WindowManager)
            .defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels; sh = dm.heightPixels
    }

    fun tap(xf: Float, yf: Float) {
        refreshSize()
        val p = Path().apply { moveTo(xf * sw, yf * sh) }
        val g = GestureDescription.Builder().addStroke(StrokeDescription(p, 0, 60)).build()
        dispatchGesture(g, null, null)
    }

    /** dir: -1 hold left, 1 hold right, 0 release. Safe to call every frame. */
    fun setHold(dir: Int) {
        if (dir == desiredDir) return
        desiredDir = dir
        if (dir == 0) return                       // the running chain will release itself
        refreshSize()
        val x = (if (dir < 0) Config.LEFT_X else Config.RIGHT_X) * sw
        val p = Path().apply { moveTo(x, Config.BTN_Y * sh) }
        path = p
        activeDir = dir
        val s = StrokeDescription(p, 0, Config.HOLD_CHUNK_MS, true)
        stroke = s
        dispatch(s, dir)
    }

    private fun dispatch(s: StrokeDescription, dir: Int) {
        val g = GestureDescription.Builder().addStroke(s).build()
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(gd: GestureDescription?) {
                if (activeDir != dir) return       // superseded by a newer hold
                val p = path ?: return
                val keep = desiredDir == dir
                val next = s.continueStroke(p, 0, if (keep) Config.HOLD_CHUNK_MS else 1, keep)
                stroke = next
                if (!keep) activeDir = 0
                dispatch(next, dir)
            }
        }, null)
    }
}
