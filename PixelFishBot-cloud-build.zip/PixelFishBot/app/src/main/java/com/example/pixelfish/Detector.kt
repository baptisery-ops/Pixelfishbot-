package com.example.pixelfish

import java.nio.ByteBuffer
import kotlin.math.abs

/** Zero-allocation per-frame analysis straight off the RGBA ImageReader buffer. */
class Detector {
    var barPresent = false; private set
    /** Positions as 0..1 across the bar; NaN when not found. */
    var ringX = Float.NaN; private set
    var fishX = Float.NaN; private set
    var hookGreen = false; private set

    private val ringCols = IntArray(4096)
    private val fishCols = IntArray(4096)

    fun analyze(buf: ByteBuffer, rowStride: Int, w: Int, h: Int) {
        analyzeBar(buf, rowStride, w, h)
        analyzeHook(buf, rowStride, w, h)
    }

    private fun analyzeBar(buf: ByteBuffer, rowStride: Int, w: Int, h: Int) {
        val x0 = (Config.BAR_LEFT * w).toInt()
        val x1 = (Config.BAR_RIGHT * w).toInt()
        val y0 = (Config.BAR_TOP * h).toInt()
        val y1 = (Config.BAR_BOTTOM * h).toInt()
        val n = (x1 - x0).coerceAtMost(ringCols.size)
        java.util.Arrays.fill(ringCols, 0, n, 0)
        java.util.Arrays.fill(fishCols, 0, n, 0)
        var blue = 0
        var total = 0
        for (y in y0 until y1) {
            var off = y * rowStride + x0 * 4
            for (i in 0 until n) {
                val r = buf.get(off).toInt() and 0xFF
                val g = buf.get(off + 1).toInt() and 0xFF
                val b = buf.get(off + 2).toInt() and 0xFF
                off += 4
                total++
                when {
                    g > 170 && g > r + 70 && g > b + 70 -> ringCols[i]++            // bright green ring
                    b > 110 && b > r + 50 && b >= g -> blue++                        // bar background
                    (r + g + b) < 225 || (r > 150 && g < 90 && b < 90) -> fishCols[i]++ // dark/red fish
                }
            }
        }
        barPresent = total > 0 && blue.toFloat() / total > Config.BAR_BLUE_FRAC
        if (!barPresent) { ringX = Float.NaN; fishX = Float.NaN; return }

        // ring centroid
        var rc = 0L; var rs = 0L
        for (i in 0 until n) { rc += ringCols[i]; rs += ringCols[i].toLong() * i }
        if (rc < Config.MIN_RING_PIXELS) { ringX = Float.NaN; fishX = Float.NaN; return }
        val ringIdx = rs.toFloat() / rc
        ringX = ringIdx / n

        // fish centroid, ignoring the ring's own dark outline
        val excl = Config.RING_EXCLUDE_FRAC * n
        var fc = 0L; var fs = 0L
        for (i in 0 until n) {
            if (abs(i - ringIdx) <= excl) continue
            fc += fishCols[i]; fs += fishCols[i].toLong() * i
        }
        fishX = if (fc >= Config.MIN_FISH_PIXELS) (fs.toFloat() / fc) / n else Float.NaN
    }

    private fun analyzeHook(buf: ByteBuffer, rowStride: Int, w: Int, h: Int) {
        val cx = (Config.ACTION_X * w).toInt()
        val cy = (Config.BTN_Y * h).toInt()
        val half = (Config.HOOK_HALF * w).toInt()
        var green = 0; var total = 0
        var y = cy - half
        while (y < cy + half) {
            var x = cx - half
            while (x < cx + half) {
                val off = y * rowStride + x * 4
                val r = buf.get(off).toInt() and 0xFF
                val g = buf.get(off + 1).toInt() and 0xFF
                val b = buf.get(off + 2).toInt() and 0xFF
                total++
                if (g > 170 && g > r + 50 && g > b + 50) green++
                x += 2
            }
            y += 2
        }
        hookGreen = total > 0 && green.toFloat() / total > Config.HOOK_GREEN_FRAC
    }
}
