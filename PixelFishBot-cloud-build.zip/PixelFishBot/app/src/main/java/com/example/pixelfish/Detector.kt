package com.example.pixelfish

import java.nio.ByteBuffer
import kotlin.math.abs

/**
 * Per-frame analysis of the RGBA ImageReader buffer.
 * Ring and fish centroids use a light exponential moving average to reduce jitter.
 */
class Detector {
    var barPresent = false; private set
    /** Positions normalized to 0..1 across the bar; NaN when not found. */
    var ringX = Float.NaN; private set
    var fishX = Float.NaN; private set
    var hookGreen = false; private set

    private val ringCols = IntArray(4096)
    private val fishCols = IntArray(4096)

    // Larger alpha reacts faster; smaller alpha smooths more.
    private val ringAlpha = 0.45f
    private val fishAlpha = 0.35f
    private var smoothedRingX = Float.NaN
    private var smoothedFishX = Float.NaN

    private fun smooth(previous: Float, current: Float, alpha: Float): Float {
        if (current.isNaN()) return Float.NaN
        if (previous.isNaN()) return current
        return previous + alpha * (current - previous)
    }

    private fun resetBarPositions() {
        ringX = Float.NaN
        fishX = Float.NaN
        smoothedRingX = Float.NaN
        smoothedFishX = Float.NaN
    }

    fun analyze(buf: ByteBuffer, rowStride: Int, w: Int, h: Int) {
        analyzeBar(buf, rowStride, w, h)
        analyzeHook(buf, rowStride, w, h)
    }

    private fun analyzeBar(buf: ByteBuffer, rowStride: Int, w: Int, h: Int) {
        val x0 = (Config.BAR_LEFT * w).toInt()
        val x1 = (Config.BAR_RIGHT * w).toInt()
        val y0 = (Config.BAR_TOP * h).toInt()
        val y1 = (Config.BAR_BOTTOM * h).toInt()
        val n = (x1 - x0).coerceAtMost(ringCols.size)

        if (n <= 0 || y1 <= y0 || x0 < 0 || y0 < 0 || x1 * 4 > rowStride || y1 * rowStride > buf.limit()) {
            barPresent = false
            resetBarPositions()
            return
        }

        java.util.Arrays.fill(ringCols, 0, n, 0)
        java.util.Arrays.fill(fishCols, 0, n, 0)

        var blue = 0
        var total = 0
        for (y in y0 until y1) {
            var off = y * rowStride + x0 * 4
            for (i in 0 until n) {
                if (off < 0 || off + 2 >= buf.limit()) break
                val r = buf.get(off).toInt() and 0xFF
                val g = buf.get(off + 1).toInt() and 0xFF
                val b = buf.get(off + 2).toInt() and 0xFF
                off += 4
                total++
                when {
                    g > 170 && g > r + 70 && g > b + 70 -> ringCols[i]++
                    b > 110 && b > r + 50 && b >= g -> blue++
                    (r + g + b) < 225 || (r > 150 && g < 90 && b < 90) -> fishCols[i]++
                }
            }
        }

        barPresent = total > 0 && blue.toFloat() / total > Config.BAR_BLUE_FRAC
        if (!barPresent) {
            resetBarPositions()
            return
        }

        // Green ring centroid.
        var rc = 0L
        var rs = 0L
        for (i in 0 until n) {
            rc += ringCols[i]
            rs += ringCols[i].toLong() * i
        }
        if (rc < Config.MIN_RING_PIXELS) {
            resetBarPositions()
            return
        }

        val ringIdx = rs.toFloat() / rc
        val rawRingX = ringIdx / n
        smoothedRingX = smooth(smoothedRingX, rawRingX, ringAlpha)
        ringX = smoothedRingX

        // Fish centroid, excluding the ring's own dark outline.
        val excl = Config.RING_EXCLUDE_FRAC * n
        var fc = 0L
        var fs = 0L
        for (i in 0 until n) {
            if (abs(i - ringIdx) <= excl) continue
            fc += fishCols[i]
            fs += fishCols[i].toLong() * i
        }

        val rawFishX = if (fc >= Config.MIN_FISH_PIXELS) {
            (fs.toFloat() / fc) / n
        } else {
            Float.NaN
        }

        if (rawFishX.isNaN()) {
            // Don't feed a stale fish position to the controller when the fish is not detected.
            smoothedFishX = Float.NaN
            fishX = Float.NaN
        } else {
            smoothedFishX = smooth(smoothedFishX, rawFishX, fishAlpha)
            fishX = smoothedFishX
        }
    }

    private fun analyzeHook(buf: ByteBuffer, rowStride: Int, w: Int, h: Int) {
        val cx = (Config.ACTION_X * w).toInt()
        val cy = (Config.BTN_Y * h).toInt()
        val half = (Config.HOOK_HALF * w).toInt()
        var green = 0
        var total = 0
        var y = cy - half
        while (y < cy + half) {
            var x = cx - half
            while (x < cx + half) {
                val off = y * rowStride + x * 4
                if (x >= 0 && y >= 0 && off >= 0 && off + 2 < buf.limit()) {
                    val r = buf.get(off).toInt() and 0xFF
                    val g = buf.get(off + 1).toInt() and 0xFF
                    val b = buf.get(off + 2).toInt() and 0xFF
                    total++
                    if (g > 170 && g > r + 50 && g > b + 50) green++
                }
                x += 2
            }
            y += 2
        }
        hookGreen = total > 0 && green.toFloat() / total > Config.HOOK_GREEN_FRAC
    }
}
