package com.example.pixelfish

import android.util.Log
import kotlin.math.abs

/** State machine + controller. Called once per captured frame on the capture thread. */
class Bot {
    private enum class S { IDLE, FISHING }

    private var state = S.IDLE
    private var lastBarSeen = 0L
    private var lastTap = 0L
    private var nextCastAt = 0L
    private var dir = 0

    private fun svc() = BotAccessibilityService.instance

    fun onFrame(d: Detector, now: Long) {
        val a = svc() ?: return
        if (d.barPresent) {
            if (state != S.FISHING) { state = S.FISHING; Log.d(TAG, "fish on") }
            lastBarSeen = now
            control(d, a)
            return
        }
        if (state == S.FISHING) {
            if (now - lastBarSeen < Config.BAR_LOST_MS) return   // brief flicker
            state = S.IDLE
            setDir(0, a)
            nextCastAt = now + Config.POST_FISH_DELAY_MS
            lastTap = now
            Log.d(TAG, "fish done")
            return
        }
        // IDLE: strike if the hook lights up, otherwise (re)cast
        if (d.hookGreen && now - lastTap > Config.STRIKE_COOLDOWN_MS) {
            a.tap(Config.ACTION_X, Config.BTN_Y); lastTap = now; Log.d(TAG, "strike")
        } else if (now >= nextCastAt && now - lastTap > Config.CAST_RETRY_MS) {
            a.tap(Config.ACTION_X, Config.BTN_Y); lastTap = now; Log.d(TAG, "cast")
        }
    }

    private fun control(d: Detector, a: BotAccessibilityService) {
        if (d.ringX.isNaN()) { setDir(0, a); return }
        val err = if (d.fishX.isNaN()) 0f else d.fishX - d.ringX   // fish hidden under ring => centered
        var want = dir
        if (err > Config.ENTER_DEADZONE) want = 1
        else if (err < -Config.ENTER_DEADZONE) want = -1
        else if (abs(err) < Config.EXIT_DEADZONE) want = 0
        setDir(want, a)
    }

    private fun setDir(want: Int, a: BotAccessibilityService) {
        if (want == dir) return
        dir = want
        a.setHold(if (Config.INVERT_CONTROLS) -want else want)
    }

    fun release() { svc()?.setHold(0); dir = 0; state = S.IDLE }

    companion object { const val TAG = "PixelFish" }
}
