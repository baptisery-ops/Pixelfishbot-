package com.example.pixelfish

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val REQ = 42

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 24, 48, 24)
        }
        col.addView(TextView(this).apply {
            text = "1) Enable the accessibility service (Pixel Fish Bot)\n" +
                "2) Tap Start, allow screen capture\n" +
                "3) Switch to Pixel Worlds and open the fishing spot (landscape)\n" +
                "Stop from the notification or here."
            textSize = 15f
        })
        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; setOnClickListener { onClick() }
        }.also { col.addView(it) }

        btn("1. Accessibility settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("2. Start") {
            if (BotAccessibilityService.instance == null) {
                Toast.makeText(this, "Enable the accessibility service first", Toast.LENGTH_LONG).show()
            } else {
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                @Suppress("DEPRECATION")
                startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
            }
        }
        btn("Stop") { startService(Intent(this, BotService::class.java).setAction(BotService.ACTION_STOP)) }
        setContentView(col)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ && res == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, BotService::class.java)
                    .putExtra(BotService.EXTRA_CODE, res)
                    .putExtra(BotService.EXTRA_DATA, data)
            )
        }
    }
}
