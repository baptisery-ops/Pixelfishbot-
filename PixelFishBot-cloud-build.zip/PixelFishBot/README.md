# Pixel Fish Bot (untested first draft)
Open this folder in Android Studio (Koala+), let it sync, run on a device (Android 8+).
Landscape only. Flow: enable accessibility service -> Start -> switch to the game's fishing spot.
Tune app/src/main/java/com/example/pixelfish/Config.kt (all positions are screen fractions).
Debug with: adb logcat -s PixelFish
